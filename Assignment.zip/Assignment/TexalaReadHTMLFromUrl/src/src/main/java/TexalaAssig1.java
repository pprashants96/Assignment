package src.main.java;
import java.net.*;

import src.main.java.service.Service;

import java.io.*;

public class TexalaAssig1 {
    public static void main(String[] args) throws Exception {
        boolean flag = Service.read();
    }
}