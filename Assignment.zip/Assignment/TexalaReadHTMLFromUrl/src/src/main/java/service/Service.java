package src.main.java.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;

public class Service {

	public static boolean read() throws Exception{
		URL yahoo = new URL("http://www.google.com");
        URLConnection yc = yahoo.openConnection();
        File targetFile = new File ("C://test.txt");
        OutputStream out = new FileOutputStream(targetFile);
        byte[] buffer = new byte[8 * 1024];
        int bytesRead;
        while ((bytesRead = yc.getInputStream().read(buffer)) != -1) 
            out.write(buffer,0,bytesRead);
		return true;
	}

}
