package src.main.test;

import org.junit.jupiter.api.Test;

import src.main.java.service.Service;

public class Junit {

	@Test
	public void testService() {
		assertTrue(Service.read(), true);
	}
	
}
